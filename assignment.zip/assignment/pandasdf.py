import pandas as pd
dict_table ={"Name":["Nitish Kumar", "Manish Kumar", "Ajay Kumar"],
             "Phone":[1234,4567,789678],
              "City":["Delhi","Patna","Gaya"]
              }

print(pd.DataFrame(dict_table))