import pandas as pd
import os
from docxtpl import DocxTemplate

# Taking the filepath to the Word Template

# docpath=r"C:\Users\hp\Desktop\assignment\temp_file_1.docx"
# docpath=r"C:\Users\hp\Desktop\assignment\temp_file_2.docx"
# docpath=r"C:\Users\hp\Desktop\assignment\temp_file_3.docx"
# docpath=r"C:\Users\hp\Desktop\assignment\temp_file_4.docx"
docpath = r"C:\Users\hp\Desktop\assignment\temp_file_5.docx"

#  Filepath to the excel file which has the data means the excel sheet
datafile = pd.read_excel(r"C:\Users\hp\Desktop\assignment\Sampledata.xlsx")

# print(datafile)   # Printing the data for surity..

# getting the name of the file
mainftype = os.path.basename(docpath)
mainfname = os.path.splitext(mainftype)[0]
print("\n File Name is : ", mainfname)


# Now Setting the  folder path to where we want to save the final word  files according to the file we got...
parent_dir = ''
dir = ''
if(mainfname == "temp_file_1"):
    parent_dir = "C:/Users/hp/Desktop/"     # parent Directory....
    dir = "Master Folder"
    outputname = 'Master File'

elif (mainfname == 'temp_file_2'):
    # parent Directory....
    parent_dir = "C:/Users/hp/Desktop/Master Folder/"
    dir = "Annex A"
    outputname = 'Sub A1'

elif (mainfname == 'temp_file_3'):
    # parent Directory....
    parent_dir = "C:/Users/hp/Desktop/Master Folder/"
    dir = "Annex B"
    outputname = 'Sub B1'

else:
    # parent Directory....
    parent_dir = "C:/Users/hp/Desktop/Master Folder/"
    dir = "Annex C"
    if(mainfname == 'temp_file_4'):
        outputname = 'Sub C1'
    elif(mainfname == 'temp_file_5'):
        outputname = 'Sub C2'

my_dir = os.path.join(parent_dir, dir)

try:
    os.mkdir(my_dir)    # creating the directory according the file provided
except OSError as error:
    print(error)

os.chdir(my_dir)   # moving the directory to the our required path

# Retreving the data from the excel sheet.....
Candidate_Name = datafile["Name"].values
Company_name = datafile["Company"].values
Address = datafile["Address"].values
Number = datafile["Number"].values
List = datafile["List"].values


combined_data = zip(Candidate_Name, Company_name, Address, Number, List)

for a, b, c, d, e in combined_data:     # Fetching data one by one from the combined data

    doc = DocxTemplate(docpath)    # Reading the data which is to be replace inside inside the template folder...

    context = {"name": a, "company": b, "address": c, "number": d, "list": e}   # Placing the data over the key

    doc.render(context)
    doc.save('{}.docx'.format(outputname))   # saving the file with their provide name..

print(" File is Handled Perfectly!!")
